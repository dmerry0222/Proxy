import "server-only";

import { supabaseServer } from "@/lib/supabase/server";

import type {
  MemoryEntityResolution,
  MemoryEntityType,
} from "@/lib/memory/types";

type RelatedEntity = {
  id: string;
  entity_type: MemoryEntityType;
  canonical_name: string;
  status: string;
};

export async function resolveMemoryEntityByEmail(
  email: string | null | undefined
): Promise<MemoryEntityResolution | null> {
  const normalizedEmail =
    email?.trim().toLowerCase();

  if (!normalizedEmail) {
    return null;
  }

  const {
    data,
    error,
  } = await supabaseServer
    .from(
      "memory_entity_identifiers"
    )
    .select(`
      identifier_value,
      entity_id,
      memory_entities (
        id,
        entity_type,
        canonical_name,
        status
      )
    `)
    .eq(
      "identifier_type",
      "email"
    )
    .eq(
      "normalized_value",
      normalizedEmail
    )
    .maybeSingle();

  if (error) {
    throw new Error(
      `Failed to resolve Memory entity: ${error.message}`
    );
  }

  if (!data) {
    return null;
  }

  const related =
    data.memory_entities as
      | RelatedEntity
      | RelatedEntity[]
      | null;

  const entity =
    Array.isArray(related)
      ? related[0]
      : related;

  if (!entity) {
    return null;
  }

  if (
    entity.status ===
    "merged"
  ) {
    return null;
  }

  return {
    entityId:
      entity.id,

    entityType:
      entity.entity_type,

    canonicalName:
      entity.canonical_name,

    matchType:
      "identifier",

    matchedValue:
      normalizedEmail,
  };
}